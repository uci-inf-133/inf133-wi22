/*TODO:
 - Use fetch() to get the 10 tweets from tweets.json and print add them to the list
 - Note: must use live-server or some other server-side Javascript because of the same-origin policy
 https://stackoverflow.com/questions/69144759/fetch-api-cannot-load-url-scheme-file-is-not-supported
*/

function addListItem(text) {
    listItem = document.createElement('li');
    listItem.textContent = text;
    document.getElementById('tweet_list').appendChild(listItem);
}

//Wait for the DOM content to load
document.addEventListener('DOMContentLoaded', () => {
    //Add the 10 tweets
    
});