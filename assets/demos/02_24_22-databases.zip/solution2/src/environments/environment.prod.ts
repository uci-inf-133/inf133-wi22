export const environment = {
  firebase: {
    projectId: 'fir-inclass-3de90',
    appId: '1:750784627180:web:743cb2a436045e0f3b40c9',
    databaseURL: 'https://fir-inclass-3de90.firebaseio.com',
    storageBucket: 'fir-inclass-3de90.appspot.com',
    locationId: 'us-central',
    apiKey: 'AIzaSyBgZ4mCcrdy1KwFkdB6ste-CizdSE24OC4',
    authDomain: 'fir-inclass-3de90.firebaseapp.com',
    messagingSenderId: '750784627180',
  },
  production: true
};
