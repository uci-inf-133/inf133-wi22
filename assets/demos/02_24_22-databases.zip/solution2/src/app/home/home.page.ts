import { Component } from '@angular/core';
import { Firestore, doc, deleteDoc, setDoc, getDoc } from '@angular/fire/firestore';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {

  loggedIn:boolean = false;
  username:string = undefined;

  constructor(private db:Firestore) {
    getDoc(doc(this.db, 'users', 'account')).then((response:any) => {
      var data = response.data();
      if(data && data.username) {
        this.username = data.username;
        this.loggedIn = true;
      }
    });
  }

  logIn() {
    setDoc(doc(this.db, 'users', 'account'), {'username': this.username}).then(() => {
      this.loggedIn = true;
    });
  }

  logOut() {
    deleteDoc(doc(this.db, 'users', 'account')).then(() => {
      this.loggedIn = false;
      this.username = undefined;
    });
  }

}
