import { Component } from '@angular/core';
import { Storage } from '@capacitor/storage';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {

  loggedIn:boolean = false;
  username:string = undefined;

  constructor() {
    Storage.get({key:'username'}).then((usr) => {
      if(usr.value) {
        this.username = usr.value;
        this.loggedIn = true;
      }
    });
  }

  logIn() {
    Storage.set({key:"username", value:this.username}).then(() => {
      this.loggedIn = true;
    })
  }

}
