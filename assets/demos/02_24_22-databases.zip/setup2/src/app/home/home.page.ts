import { Component } from '@angular/core';
import { Firestore, doc, deleteDoc, setDoc, getDoc } from '@angular/fire/firestore';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {

  loggedIn:boolean = false;
  username:string = undefined;

  constructor(private db:Firestore) {
    //use getDoc to access the "account" document in the "users" collection.
    //If it exists and has a username, set the username and log in
  }

  logIn() {
    //use setDoc to set the "account" document in the "users" collection.
    //set the "username" field of that document to be the name bound to the username variable
  }

  logOut() {
    //use deleteDoc to delete the "account" document in the "users" collection.
    //after the document is deleted, log out and clear the username variable.
  }

}
