export const environment = {
  //TODO: update this file
  production: true
};
