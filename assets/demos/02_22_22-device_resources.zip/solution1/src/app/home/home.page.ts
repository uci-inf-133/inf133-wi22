import { Component } from '@angular/core';
import { Capacitor } from '@capacitor/core';
import { Camera, CameraResultType, CameraPhoto, CameraSource } from '@capacitor/camera';
import { LocalNotifications } from '@capacitor/local-notifications';
import { Share } from '@capacitor/share';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {

  readyForSelfie:boolean = false;
  selfieTaken:boolean = false;
  photo:CameraPhoto = null;
  photoURL:string = null;

  constructor() {}

  async scheduleSelfie() {
     await LocalNotifications.requestPermissions();
    var notification = await LocalNotifications.schedule({
      notifications: [
        {
          title: 'Daily Selfie Reminder',
          body: 'Time to take a selfie!',
          id: 1,
          schedule: { at: new Date(Date.now()) },
        },
      ],
    });
    //You'd ideally want to listen for the notification to be received, but this does not appear to be enabled for web
    this.readyForSelfie = true;
  }

  async takeSelfie() {
    this.photo = await Camera.getPhoto({
      resultType: CameraResultType.Uri,
      source: CameraSource.Camera,
      quality: 100,
    });
    this.photoURL = Capacitor.convertFileSrc(this.photo.webPath);
    this.selfieTaken = true;
  }

  async shareSelfie() {
    //Can't actually share the file because web support currently doesn't enable it :-(
    Share.share({
      text: 'Hello from IN4MATX 133 lecture!',
      dialogTitle: 'Share with TAs'
    });
  }

}
