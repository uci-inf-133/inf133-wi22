/*
 - Write the function in plain JavaScript to join the array of strings on the "join" character, concatenating the results with a newline ('\n').
 - Add types to all the parameters and the return of that function
 - How does that change which function calls are legal?
*/

function joinNTimes(arrOfStr:any[], joinStr:string, n:number):string {
	var joinedStr:string = '';
	for(var i:number=0;i<n;i++) {
		joinedStr += arrOfStr.join(joinStr) + '\n';
	}
	return joinedStr;
}

console.log(joinNTimes(['hello', 'my', 'name', 'is', 'theresa'], ' ', 3));
//console.log(joinNTimes(['in4matx', 133], '-', 2))
//console.log(joinNTimes(['two', 'too', 'to'], 2, 4))