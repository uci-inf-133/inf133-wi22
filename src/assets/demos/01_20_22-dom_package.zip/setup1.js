/*
	- After 1 second, add the "title" class to the h1 tag and change its color to blue.
	- After 2 seconds, change the text of the first paragraph (id "first") to "Lorem ipsum amet".
	- After 3 seconds, add a new paragraph to the div (id "body") with the text "A new paragraph!"
*/

function runJS() {
	setTimeout(() => {
		
	}, 1000);

	setTimeout(() => {
		
	}, 2000);

	setTimeout(() => {
		
	}, 3000);
}