/*
	- After 1 second, add the "title" class to the h1 tag and change its color to blue.
	- After 2 seconds, change the text of the first paragraph (id "first") to "Lorem ipsum amet".
	- After 3 seconds, add a new paragraph to the div (id "body") with the text "A new paragraph!"
*/

function runJS() {
	setTimeout(() => {
		var elements = document.getElementsByTagName("h1");
		for(var i = 0; i < elements.length; i++) {
			elements[i].classList.add("title");
			elements[i].style.color="blue";
		}
	}, 1000);

	setTimeout(() => {
		var elem = document.querySelector('#first');
		elem.textContent = "Lorem ipsum amet";
	}, 2000);

	setTimeout(() => {
		var div = document.querySelector('div#body');
		var newP = document.createElement('p');
		newP.textContent = "A new paragraph!";
		div.appendChild(newP);
	}, 3000);
}