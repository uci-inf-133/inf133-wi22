import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class RigDiceService {
  die1:number[] = [];
  die2:number[] = [];
  die1Index:number = 0;
  die2Index:number = 0;

  constructor(private http:HttpClient) {
    //TODO: use the HTTP client to get the rigged die rolls from the JSON file in the assets folder
    //Add the values to the arrays for die1 and die2
  }

  //TODO: first, have the service roll fair dice by using Math.random() to roll.
  //Then, update the service to return the rigged die rolls in order.
  rollDie1():number {
    return -1;
  }

  rollDie2():number {
    return -1;
  }
}
